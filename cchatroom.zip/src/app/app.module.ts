import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PageRegisterComponent } from './pages/page-register/page-register.component';
import { PageChatComponent } from './pages/page-chat/page-chat.component';
import { FormSignUpComponent } from './forms/form-sign-up/form-sign-up.component';

import { FormsModule } from "@angular/forms";
import { HttpClientModule } from "@angular/common/http";
@NgModule({
  declarations: [
    AppComponent,
    PageRegisterComponent,
    PageChatComponent,
    FormSignUpComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule, // for the [(banana in the box)]
    HttpClientModule // for API calls
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
