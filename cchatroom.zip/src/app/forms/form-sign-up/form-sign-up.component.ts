import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/services/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-form-sign-up',
  templateUrl: './form-sign-up.component.html',
  styleUrls: ['./form-sign-up.component.scss']
})
export class FormSignUpComponent implements OnInit {
  username;
  password;
  passwordConfirm;

  constructor(
    private userS: UserService,
    private router: Router
  ) { }

  ngOnInit() {
  }
  submitSignUp() {
    // check for values
    console.log(this.username, this.password);

    this.userS
      .register(this.username, this.password)
      .subscribe(res => {
        console.log(res);
        if (res.code == 0) {
          alert(res.serverMsg);
        } else if (res.code == -1) {
          alert(res.serverMsg);
        } else {
          alert(res.serverMsg);
          this.userS.saveHash(res.code);
          this.router.navigate(["/chat"]);
        }
      })
  }
  login(){
    // check for values
    console.log(this.username, this.password);

    this.userS
      .login(this.username, this.password)
      .subscribe(res => {
        console.log(res);
        if (res.code == 0) {
          alert(res.serverMsg);
        } else if (res.code == -1) {
          alert(res.serverMsg);
        } else {
          alert(res.serverMsg);
          this.userS.saveHash(res.code);
          this.router.navigate(["/chat"]);
        }
      })
  }
}
