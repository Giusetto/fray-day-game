import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  baseUrl = "https://ajax.igor-marty.fr";
  hashCode: string;

  constructor(private http: HttpClient) { }

  register(login, password): Observable<any> {
    return this.http.post(
      this.baseUrl + "/signin",
      {
        "login": login,
        "password": password
      }
    );
  }
  login(login, password): Observable<any> {
    return this.http.post(
      this.baseUrl + "/login",
      {
        "login": login,
        "password": password
      }
    );
  }

  saveHash(code) {
    this.hashCode = code;
  }

  

}
