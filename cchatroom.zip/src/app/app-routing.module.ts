import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PageRegisterComponent } from './pages/page-register/page-register.component';
import { PageChatComponent } from './pages/page-chat/page-chat.component';


const routes: Routes = [
  {
    path: '',
    redirectTo: "register",
    pathMatch: "full"
  },
  {
    path: "chat",
    component: PageChatComponent
  },
  {
    path: "register",
    component: PageRegisterComponent
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
